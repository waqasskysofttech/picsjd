<footer>
    <div class="footer-top pb-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <!-- <h4 class="dark-gren-36" data-aos="flip-down" data-aos-duration="1500">Edusauras
                        Works</h4> -->
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <!-- <a class="" href="#">
                                <svg xmlns="http://www.w3.org/2000/svg" width="27" height="27" viewBox="0 0 27 27">
                                    <path id="Icon_ionic-logo-facebook" data-name="Icon ionic-logo-facebook"
                                        d="M30.009,4.5H5.991A1.491,1.491,0,0,0,4.5,5.991V30.009A1.491,1.491,0,0,0,5.991,31.5H18V20.813H14.773V16.875H18V13.964c0-3.488,2.419-5.386,5.534-5.386,1.491,0,3.094.113,3.466.162v3.642H24.518c-1.695,0-2.018.8-2.018,1.983v2.51h4.036l-.527,3.938H22.5V31.5h7.509A1.491,1.491,0,0,0,31.5,30.009V5.991A1.491,1.491,0,0,0,30.009,4.5Z"
                                        transform="translate(-4.5 -4.5)" fill="#1877f2" />
                                </svg>
                            </a> -->
                            <!-- <a class="" href="#">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                    width="27" height="27" viewBox="0 0 27 27">
                                    <defs>
                                        <linearGradient id="linear-gradient" y1="0.028" x2="1.063" y2="1.063"
                                            gradientUnits="objectBoundingBox">
                                            <stop offset="0" stop-color="#6248c5" />
                                            <stop offset="0.343" stop-color="#be3289" />
                                            <stop offset="0.674" stop-color="#f36a39" />
                                            <stop offset="1" stop-color="#fecb69" />
                                        </linearGradient>
                                    </defs>
                                    <path id="Icon_metro-instagram" data-name="Icon metro-instagram"
                                        d="M25.088,1.928H7.053A4.5,4.5,0,0,0,2.571,6.41V24.446a4.5,4.5,0,0,0,4.482,4.482H25.088a4.5,4.5,0,0,0,4.482-4.482V6.41a4.5,4.5,0,0,0-4.482-4.482ZM11.214,13.741h9.714a5.142,5.142,0,1,1-9.714,0Zm14.982,0V23.866a1.692,1.692,0,0,1-1.687,1.688H7.633a1.692,1.692,0,0,1-1.687-1.687V13.741h2.64a7.673,7.673,0,1,0,14.971,0H26.2Zm0-5.908a.846.846,0,0,1-.844.844H23.664a.846.846,0,0,1-.844-.844V6.147a.846.846,0,0,1,.844-.844h1.688a.846.846,0,0,1,.844.844Z"
                                        transform="translate(-2.571 -1.928)" fill="url(#linear-gradient)" />
                                </svg>
                            </a> -->
                            <!-- <a class="" href="#">
                                <svg xmlns="http://www.w3.org/2000/svg" width="38.4" height="27" viewBox="0 0 38.4 27">
                                    <path id="Icon_awesome-youtube" data-name="Icon awesome-youtube"
                                        d="M38.648,8.725a4.825,4.825,0,0,0-3.395-3.417c-2.995-.808-15-.808-15-.808s-12.008,0-15,.808A4.825,4.825,0,0,0,1.852,8.725c-.8,3.014-.8,9.3-.8,9.3s0,6.289.8,9.3a4.753,4.753,0,0,0,3.395,3.362c2.995.808,15,.808,15,.808s12.008,0,15-.808a4.753,4.753,0,0,0,3.395-3.362c.8-3.014.8-9.3.8-9.3s0-6.289-.8-9.3ZM16.323,23.737V12.318l10.036,5.71L16.323,23.737Z"
                                        transform="translate(-1.05 -4.5)" fill="red" />
                                </svg>

                            </a> -->
                        </li>
                    </ul>
                </div>
                <div class="col-lg-4">
                    <!-- <h3 class="dark-gren-24" data-aos="fade-up" data-aos-duration="1500">Quick Links</h3> -->
                    <div class="row">
                        <!-- <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Home</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0 " href="#">News</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Explorer</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Partners</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Educator</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Contact Us</a>
                        </div>
                        <div class="col-lg-6">
                            <a class="nav-link pl-0" href="#">Contribute</a>
                        </div> -->
                    </div>
                </div>
                <div class="col-lg-4">
                    <!-- <h3 class="dark-gren-24" data-aos="fade-up" data-aos-duration="1500">Contact Us</h3> -->
                    <div class="pt-2">
                        <!-- <svg xmlns="http://www.w3.org/2000/svg" width="10.118" height="7.588"
                            viewBox="0 0 10.118 7.588">
                            <path id="Icon_awesome-envelope" data-name="Icon awesome-envelope"
                                d="M9.926,7.006a.119.119,0,0,1,.192.093V11.14a.949.949,0,0,1-.949.949H.949A.949.949,0,0,1,0,11.14V7.1a.118.118,0,0,1,.192-.093c.443.344,1.03.781,3.045,2.245a3.535,3.535,0,0,0,1.822.941,3.537,3.537,0,0,0,1.824-.941C8.9,7.788,9.483,7.35,9.926,7.006ZM5.059,9.559c.458.008,1.118-.577,1.45-.818C9.131,6.838,9.331,6.672,9.936,6.2a.473.473,0,0,0,.182-.373V5.449A.949.949,0,0,0,9.169,4.5H.949A.949.949,0,0,0,0,5.449v.375A.476.476,0,0,0,.182,6.2c.6.472.8.64,3.427,2.543C3.94,8.982,4.6,9.567,5.059,9.559Z"
                                transform="translate(0 -4.5)" fill="#ff6f92" />
                        </svg> -->

                        <!-- <span class="fotr-contus">info@support.com</span> -->
                    </div>
                    <div class="pt-2">
                        <!-- <svg xmlns="http://www.w3.org/2000/svg" width="10.117" height="10.117"
                            viewBox="0 0 10.117 10.117">
                            <path id="Icon_awesome-phone-alt" data-name="Icon awesome-phone-alt"
                                d="M9.829,7.15,7.616,6.2a.474.474,0,0,0-.553.136l-.98,1.2a7.325,7.325,0,0,1-3.5-3.5l1.2-.98A.473.473,0,0,0,3.915,2.5L2.966.287A.477.477,0,0,0,2.423.012L.368.487A.474.474,0,0,0,0,.949a9.168,9.168,0,0,0,9.169,9.169.474.474,0,0,0,.462-.368L10.106,7.7a.48.48,0,0,0-.277-.545Z"
                                transform="translate(0 0)" fill="#ff6f92" />
                        </svg> -->

                        <!-- <span class="fotr-contus">000-111-2222</span> -->
                    </div>
                    <div class="pt-2">
                        <!-- <svg xmlns="http://www.w3.org/2000/svg" width="10.117" height="10.118"
                            viewBox="0 0 10.117 10.118">
                            <path id="Icon_awesome-location-arrow" data-name="Icon awesome-location-arrow"
                                d="M8.784.07.568,3.862A.958.958,0,0,0,.947,5.695H4.424V9.171a.958.958,0,0,0,1.833.379l3.792-8.216A.986.986,0,0,0,8.784.07Z"
                                transform="translate(0)" fill="#ff6f92" />
                        </svg> -->

                        <!-- <span class="fotr-contus">80 Kemper Lane DICE KY Kentucky</span> -->
                    </div>
                </div>
            </div>
        </div>
        <img src="{{asset('images/world.png')}}" class="world-picc" alt="">
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                <div class="col-12 col-sm-12 text-center">
                    <p>© 2021 Edausauras. All Rights Reserved</p>
                </div>
            </div>
        </div>
    </div>
</footer>