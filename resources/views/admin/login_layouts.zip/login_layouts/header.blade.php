<section class="head-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <img src="{{asset($logo->img_path)}}" class="img-fluid" alt="">
                </div>
                <div class="col-lg-6">

                    <ul class="nav navbar-nav float-right">
                        <li class="dropdown dropdown-notification nav-item"> <a class="nav-link nav-link-label" href="#"
                                data-toggle="dropdown">
                                <!-- <svg xmlns="http://www.w3.org/2000/svg" width="19.027"
                                    height="19.021" viewBox="0 0 19.027 19.021">
                                    <path id="bellalt"
                                        d="M6.548,19.021,5.359,17.832A7.339,7.339,0,0,0,4.495,15a10.575,10.575,0,0,0-2.108-3.056l-.409-.409A6.519,6.519,0,0,1,.056,7.578,6.564,6.564,0,0,1,.938,3.343a1.974,1.974,0,0,1-.669-.65,1.664,1.664,0,0,1-.26-.91A1.714,1.714,0,0,1,.538.529,1.712,1.712,0,0,1,1.792,0a1.707,1.707,0,0,1,.92.26,1.751,1.751,0,0,1,.641.688A6.518,6.518,0,0,1,7.588.075a6.529,6.529,0,0,1,3.938,1.913l.409.409a10.7,10.7,0,0,0,3.074,2.09,7.462,7.462,0,0,0,2.833.864l1.189,1.189a11.311,11.311,0,0,1-1.04,4.7,13.408,13.408,0,0,1-2.74,4,13.374,13.374,0,0,1-4,2.739A11.34,11.34,0,0,1,6.548,19.021ZM16.968,7.412q-.576-.539-1.941-.037a11,11,0,0,0-3,1.82,2.142,2.142,0,0,1,.771.752A1.975,1.975,0,0,1,13.086,11a2.061,2.061,0,0,1-2.08,2.08,1.981,1.981,0,0,1-1.049-.288,2.137,2.137,0,0,1-.752-.771,10.987,10.987,0,0,0-1.82,3q-.5,1.365.037,1.941.688.688,2.563-.223a14.686,14.686,0,0,0,3.863-2.9,14.686,14.686,0,0,0,2.9-3.863q.91-1.876.223-2.563Z"
                                        transform="translate(-0.005)" fill="#ff6f92" />
                                </svg> -->
                                <!-- <span
                                    class="badge badge-pill badge-default badge-danger badge-default badge-up">3</span> -->
                            </a>
                            <ul class="dropdown-menu dropdown-menu-media dropdown-menu-right new">
                                <li class="dropdown-menu-header">
                                    <!-- <h6 class="dropdown-header m-0"> <span class="theme-blue-txt">Notifications</span> -->

                                    </h6>
                                </li>
                                <!-- <li class="scrollable-container media-list ps-container ps-theme-dark ps-active-y"
                                    data-ps-id="b71981fd-a505-a3e0-8a77-fcc659214745">
                                    <a href="javascript:void(0)">
                                        <div class="media">
                                            <img src="images/avatar1.png" class="mr-3" alt="...">
                                            <div class="media-body">
                                                <p>Lorem ipsum dolor sit amet, consectetur adip ear elit sed do eiusmod
                                                    tempor dolore magna aliqua. Ut enim ad minim.</p>
                                                <small>
                                                    <div class="d-flex">
                                                        <time class="media-meta theme-blue-txt "
                                                            datetime="2015-06-11T18:29:20+08:00">March 25, 2020 - 10:30
                                                            PM</time>
                                                    </div>
                                                </small>
                                            </div>
                                        </div>
                                    </a>
                                    <hr>
                                    <a href="javascript:void(0)">
                                        <div class="media">
                                            <img src="images/avatar1.png" class="mr-3" alt="...">
                                            <div class="media-body">
                                                <p>Lorem ipsum dolor sit amet, consectetur adip ear elit sed do eiusmod
                                                    tempor dolore magna aliqua. Ut enim ad minim.</p>
                                                <small>
                                                    <div class="d-flex">
                                                        <time class="media-meta theme-blue-txt "
                                                            datetime="2015-06-11T18:29:20+08:00">March 25, 2020 - 10:30
                                                            PM</time>
                                                    </div>
                                                </small>
                                            </div>
                                        </div>
                                    </a>
                                </li> -->
                                <!-- <li class="dropdown-menu-footer"><a class="dropdown-item theme-blue-txt text-center"
                                        href="notification.php">View All Notifications</a>
                                </li> -->

                            </ul>
                        </li>
                        <li class="dropdown dropdown-user nav-item"> 
                            <!-- <a
                                class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                                <span class="avatar avatar-online"><i class="fas fa-user-circle"></i></span>
                                <span class="user-name">Jason Albert</span> </a> -->
                            <div class="dropdown-menu dropdown-menu-right">
                                <!-- <a class="dropdown-item" href="my-profile.php"><i class="far fa-user"></i> My
                                    Profile</a>
                                <a class="dropdown-item" href="#_" data-dismiss="modal" data-toggle="modal"
                                    data-target="#log-out"><i class="fas fa-sign-out-alt red"></i><span class="red">
                                        Logout</span></a> -->
                            </div>
                        </li>
                        <img src="{{asset('images/dynasore3.png')}}" class="img-fluid head-dynasore" alt="">
                    </ul>

                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse" id="navbarNav">
                            <!-- <ul class="navbar-nav mx-auto">
                                <li class="nav-item">
                                    <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="explore-edusauras.php">Explorer</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="educator.php">Educator</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contributor.php">Contribute</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="news.php">News</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="partners.php">Partners</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="contact-us.php">Contact Us</a>
                                </li>
                            </ul> -->
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </section>


    <!-- Modal -->
    <div class="modal fade" id="suspnd" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img src="{{asset('images/suspended.png')}}" alt="">
                    <h6 class="dark-gren-36">Your profile has been suspended.
                        Please Contact Admin for
                        more details.</h6>
                </div>
            </div>
        </div>
    </div>


    <!-- Modal -->
    <div class="modal fade" id="log-out" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body text-center">
                    <img src="{{asset('images/arrow.png')}}" alt="">
                    <h6 class="dark-gren-36">Are you sure you want
                        to log out ?</h6>
                    <a href="login.php" class="btn yellow-btn mt-0">Yes</a>
                    <a href="#_" class="btn pink-bodr-btn mt-0">No</a>
                </div>
            </div>
        </div>
    </div>