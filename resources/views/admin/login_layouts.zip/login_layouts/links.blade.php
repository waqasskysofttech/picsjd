<link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="{{asset('dash/css/owl.theme.default.min.css')}}">
    <link rel="stylesheet" href="{{asset('dash/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('dash/css/hover-min.css" type="text/css')}}">
    <link rel="stylesheet" href="{{asset('dash/css/bootstrap.min.css')}}">
    <link rel="icon" type="image/gif" sizes="32x32" href="{{asset('dash/images/favicon.ico')}}">
    <link rel="stylesheet" href="{{asset('dash/css/animate.css')}}">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link href="{{asset('dash/fonts/fontawesome/css/all.min.css')}}" rel="stylesheet">
    <link href="https://unpkg.com/gijgo@1.9.13/css/gijgo.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="{{asset('dash/css/mega-menu.css')}}" type="text/css">
    <link rel="stylesheet" href="{{asset('dash/css/slick.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('dash/css/slick-theme.css')}}" type="text/css" />
    <link rel="stylesheet" href="{{asset('dash/css/style.css')}}" type="text/css" />
    <link href="{{asset('dash/css/jquery.toast.css')}}" rel="stylesheet">