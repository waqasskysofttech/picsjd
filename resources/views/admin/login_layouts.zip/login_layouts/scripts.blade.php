

<script src="{{asset('dash/js/jquery.min.js')}}"></script>
<script src="{{asset('dash/js/jquery.exzoom.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="{{asset('dash/js/bootstrap.min.js')}}"></script>
<script src="{{asset('dash/js/jquery.toast.js')}}"></script>
<script src="{{asset('dash/js/owl.carousel.min.js')}}"></script>
<script src="{{asset('dash/js/wow.min.js')}}"></script>
<script src="{{asset('dash/js/slick.min.js')}}"></script>
<script src="https://unpkg.com/aos@next/dist/aos.js"></script>
<script src="https://unpkg.com/gijgo@1.9.13/js/gijgo.min.js" type="text/javascript"></script>
<script src="{{asset('dash/js/function.js')}}"></script>
<script>
new WOW().init();
</script>
<script>
AOS.init({
    mirror: true
});
</script>


